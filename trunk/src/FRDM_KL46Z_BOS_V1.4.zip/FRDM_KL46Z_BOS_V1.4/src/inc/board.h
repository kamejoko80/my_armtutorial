#ifndef __BOARD_H__
#define __BOARD_H__

#define RED_LED_PIN     (1<<29)
#define GREEN_LED_PIN   (1<<5)

void Init_Led(void);

#endif /* __BOARD_H__ */
