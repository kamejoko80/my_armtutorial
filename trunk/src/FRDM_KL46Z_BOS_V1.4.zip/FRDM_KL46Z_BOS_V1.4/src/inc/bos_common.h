#ifndef __BOS_COMMON__
#define __BOS_COMMON__

#include <stdio.h>
#include <stdint.h>
#include <string.h>

typedef int bool;

#define true  1
#define TRUE  1

#define false 0
#define FALSE 0

#endif /* __BOS_COMMON__ */
