#ifndef __BOS_SHELL_H__
#define __BOS_SHELL_H__

void BOS_InitShell(void);


#endif /* __BOS_SHELL_H__ */

