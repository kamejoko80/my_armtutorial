#ifndef __UART_H__
#define __UART_H__

void UART0_Init(void);

#endif /* __UART_H__ */
