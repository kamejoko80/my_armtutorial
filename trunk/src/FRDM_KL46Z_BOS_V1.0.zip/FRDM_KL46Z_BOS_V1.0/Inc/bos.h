#ifndef __BOS_H__
#define __BOS_H__

#include <stdio.h>
#include <string.h>
#include "MKL46Z4.h"

#define STATE_TERM      0x00000000 
#define STATE_READY     0x00000001 
#define STATE_RUN       0x00000002  
#define STATE_WAIT      0x00000003

#define EVT_MASK_00     (1 << 0)
#define EVT_MASK_01     (1 << 1)
#define EVT_MASK_02     (1 << 2)
#define EVT_MASK_03     (1 << 3)
#define EVT_MASK_04     (1 << 4)
#define EVT_MASK_05     (1 << 5)
#define EVT_MASK_06     (1 << 6)

#define MAX_TASKS 			10
#define MAX_WAIT_LIST   10 
#define TASK_STACK_SIZE 1024

#define LOWEST_PRIORITY 7 

#define CMXOS_OK        1
#define CMXOS_NOK       0 



typedef struct
{
  /* sw stack frame */
  uint32_t r4;
	uint32_t r5;
	uint32_t r6;
	uint32_t r7;
	uint32_t r8;
	uint32_t r9;
	uint32_t r10;
	uint32_t r11;

  /* hardware stack frame */
	uint32_t r0;
	uint32_t r1;
	uint32_t r2;
	uint32_t r3;
	uint32_t r12;
	uint32_t lr;
	uint32_t pc;
	uint32_t psr;

} stack_frame_t;

typedef struct
{
	uint8_t  stack_start[TASK_STACK_SIZE] __attribute__((aligned (4)));
	void     *stack;
	uint32_t flags;
	uint32_t wait_evt;
	uint32_t task_id;
	uint32_t start_time;
	uint32_t expire;
  uint32_t priority;	
} task_t;


typedef struct
{
	task_t *task;
} task_table_t;


void BOS_TaskInit(task_t *task, void *task_func, uint32_t priority);
void BOS_Start(void);
void BOS_WaitEvent(task_t *task, uint32_t evt_mask);
void BOS_ClearEvent(uint32_t evt_mask);
void BOS_SetEvent(uint32_t evt_mask);
void BOS_Delay(task_t *task, uint32_t tick);

#endif /* __BOS_H__ */
