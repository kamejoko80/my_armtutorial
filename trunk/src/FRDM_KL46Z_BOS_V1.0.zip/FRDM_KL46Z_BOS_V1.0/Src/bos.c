#include "bos.h"

/* gobal variables */
volatile uint32_t     bos_TaskRun = 0;
static   task_table_t bos_TaskTable[MAX_TASKS];
static   uint32_t     bos_TaskCount = 0;
static   uint32_t     bos_WaitTaskCount = 0;
static   uint32_t     bos_TaskEvt = 0;
static   uint32_t     bos_CurrentTaskIdx = 0;
static   uint32_t     bos_HighestPriority = 0;
volatile uint32_t     bos_SystemTick = 0; 
volatile uint32_t     bos_pStack;

/**
 * @brief         BOS_ErrorHook
 * @param[in]     void
 * @param[in,out] void
 * @return        void
 */
static void BOS_ErrorHook(void)
{
	printf("\r\nSys Error: No task ready\r\n");
	while(1);
}	

/**
 * @brief         BOS_TaskExit
 * @param[in]     void
 * @param[in,out] void
 * @return        void
 */ 
static void BOS_TaskExit(void)
{
	  /* Notify task terminated */  
	  bos_TaskTable[bos_CurrentTaskIdx].task->flags = STATE_TERM;
	
		/* Trigger PendSV handler */
		SCB->ICSR |= (1 << 28);	
}

/**
 * @brief         BOS_TaskInit
 * @param[in]     void *task_func, uint32_t priority
 * @param[in,out] task_t *task
 * @return        void
 */ 
void BOS_TaskInit(task_t *task, void *task_func, uint32_t priority)
{
  stack_frame_t *process_frame;

	/* Initialize task */ 
	memset(task, 0, sizeof(task_t));
	
	task->stack = (void*)(((uint32_t)task->stack_start) + TASK_STACK_SIZE - sizeof(stack_frame_t));
	process_frame = (stack_frame_t*)(task->stack);
	process_frame->r0 = 0;
	process_frame->r1 = 0;
	process_frame->r2 = 0;
	process_frame->r3 = 0;
	process_frame->r12 = 0;
	process_frame->pc = (uint32_t)task_func;
	process_frame->lr = (uint32_t)BOS_TaskExit;
	process_frame->psr = 0x21000000;

	process_frame->r4  = 0x4;
	process_frame->r5  = 0x5;
	process_frame->r6  = 0x6;
	process_frame->r7  = 0x7;
	process_frame->r8  = 0x8;
	process_frame->r9  = 0x9;
	process_frame->r10 = 0x10;
	process_frame->r11 = 0x11;
	
	task->flags = STATE_READY;
	task->task_id = bos_TaskCount;
	task->wait_evt = 0;
	task->expire = 0;
	task->start_time = 0;
	task->priority = priority;
	bos_TaskTable[bos_TaskCount].task = task;
	
	if(bos_HighestPriority > priority)
	{
		bos_HighestPriority = priority;
	}
	
	bos_TaskCount++;
	
}

/**
 * @brief         BOS_Start
 * @param[in]     void
 * @param[in,out] void
 * @return        void
 */ 
void BOS_Start(void)
{	
	NVIC_SetPriority(PendSV_IRQn, 0);
	
	/* 1ms tick */
	SysTick_Config(SystemCoreClock/1000);
	
	/* Trigger PendSV, switch to another task */
	SCB->ICSR |= (1 << 28);		
}

/**
 * @brief         BOS_Start
 * @param[in]     task_t *task, uint32_t evt_mask
 * @param[in,out] void
 * @return        void
 */ 
void BOS_WaitEvent(task_t *task, uint32_t evt_mask)
{
  task->flags = STATE_WAIT; /* task wait */
  task->wait_evt = evt_mask;
	bos_WaitTaskCount++;
	
	/* Trigger PendSV, switch to another task */
	SCB->ICSR |= (1 << 28);	
}

/**
 * @brief         BOS_ClearEvent
 * @param[in]     uint32_t evt_mask
 * @param[in,out] void
 * @return        void
 */ 
void BOS_ClearEvent(uint32_t evt_mask)
{
	bos_TaskEvt &= ~evt_mask;
}

/**
 * @brief         BOS_SetEvent
 * @param[in]     uint32_t evt_mask
 * @param[in,out] void
 * @return        void
 */ 
void BOS_SetEvent(uint32_t evt_mask)
{
	bos_TaskEvt |= evt_mask;
}

/**
 * @brief         BOS_TaskDelay
 * @param[in]     uint32_t tick
 * @param[in,out] task_t *task
 * @return        void
 */ 
void BOS_Delay(task_t *task, uint32_t tick)
{
	if (tick > 0)
	{
		task->flags = STATE_WAIT; /* task wait */
		task->start_time =  bos_SystemTick;
		task->expire = tick;
		bos_WaitTaskCount++;
	
		/* Trigger PendSV, switch to another task */
		SCB->ICSR |= (1 << 28);
	}		
}

/**
 * @brief         BOS_SaveContext
 * @param[in]     void
 * @param[in,out] void
 * @return        void
 */ 
void BOS_SaveContext(void)
{
	bos_TaskTable[bos_CurrentTaskIdx].task->stack = (void *) bos_pStack;
}

/**
 * @brief         BOS_SwitchContext
 * @param[in]     void
 * @param[in,out] void
 * @return        void
 */ 
void BOS_SwitchContext(void)
{ 
	uint32_t i;
	uint32_t task_found = 0;
  uint32_t task_idx;
	uint32_t task_priority = LOWEST_PRIORITY;
	uint32_t flags, wait_evt, start_time, expire;
	
	/* check task READY or WAIT with highest priority */
	for(i = 0; i < bos_TaskCount; i++)
	{
		flags      = bos_TaskTable[i].task->flags;
		wait_evt   = bos_TaskTable[i].task->wait_evt;
		start_time = bos_TaskTable[i].task->start_time;
		expire     = bos_TaskTable[i].task->expire;		
		
		if((flags == STATE_READY) || ((flags == STATE_WAIT) && 
			 ((wait_evt & bos_TaskEvt) || 
		   ((expire > 0) && ((bos_SystemTick - start_time) >= expire)))))
	  {
			if(bos_TaskTable[i].task->priority < task_priority)
			{
				task_priority = bos_TaskTable[i].task->priority;
				task_idx = i;
				task_found = 1;				
			}
		}					 
	}
	
	/* if found switch context */
	if (task_found)
	{
		  /* Change previous preemted stack to ready state */
		  if(bos_TaskTable[bos_CurrentTaskIdx].task->flags == STATE_RUN)
			{
				bos_TaskTable[bos_CurrentTaskIdx].task->flags = STATE_READY;
			}
		
			bos_CurrentTaskIdx = task_idx;
			bos_TaskTable[task_idx].task->flags = STATE_RUN;
		
    /* if task delay then reset expire and start_time */ 		
		if (bos_TaskTable[task_idx].task->expire > 0)
		{
				bos_TaskTable[task_idx].task->expire = 0;
			  bos_TaskTable[task_idx].task->start_time = 0;
		}
	}
	else
	{
			BOS_ErrorHook();
	}
}

/**
 * @brief         BOS_LoadContext
 * @param[in]     void
 * @param[in,out] void
 * @return        void
 */ 
void BOS_LoadContext(void)
{
	bos_pStack = (uint32_t)bos_TaskTable[bos_CurrentTaskIdx].task->stack;
}

/**
 * @brief         BOS_ExamineContextSwitch
 * @param[in]     void
 * @param[in,out] uint32_t *priority
 * @return        uint32_t
 */ 
uint32_t BOS_ExamineContextSwitch(uint32_t *priority)
{
	uint32_t i;
	uint32_t task_found = 0;
	uint32_t task_priority = LOWEST_PRIORITY;
	uint32_t flags, wait_evt, start_time, expire;
	
	/* check task READY or WAIT with highest priority */
	for(i = 0; i < bos_TaskCount; i++)
	{
		flags      = bos_TaskTable[i].task->flags;
		wait_evt   = bos_TaskTable[i].task->wait_evt;
		start_time = bos_TaskTable[i].task->start_time;
		expire     = bos_TaskTable[i].task->expire; 
		
		if((flags == STATE_READY) || ((flags == STATE_WAIT) && 
			 ((wait_evt & bos_TaskEvt) || 
		   ((expire > 0) && ((bos_SystemTick - start_time) >= expire)))))
	  {
			if(bos_TaskTable[i].task->priority < task_priority)
			{
				task_priority = bos_TaskTable[i].task->priority;
				task_found = 1;				
			}
		}					 
	}
	
	*priority = task_priority;
	
	return task_found;
}

/**
 * @brief         BOS_Schedule
 * @param[in]     void
 * @param[in,out] void
 * @return        void
 */ 
static void BOS_Schedule(void)
{
		uint32_t task_Priority;
		uint32_t cur_TaskPriority;
	  
	  cur_TaskPriority = bos_TaskTable[bos_CurrentTaskIdx].task->priority; 
	 
	  /* preempt current task if higher priority task is available */
		if(BOS_ExamineContextSwitch(&task_Priority))
		{
			if(task_Priority < cur_TaskPriority)
			{
				/* Trigger PendSV handler to switch context */
				SCB->ICSR |= (1 << 28);					
		  }
	  }	
}

/** Description : SysTick_Handler
 *  param[in]   : void
 *  param[out]  : void
 */
void SysTick_Handler (void)
{	
	bos_SystemTick++;
	BOS_Schedule();
}
