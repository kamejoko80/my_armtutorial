#include <stdio.h>
#include <string.h>
#include "MKL46Z4.h"
#include "uart.h"
#include "bos.h"

#define RED_LED_PIN     (1<<29)
#define GREEN_LED_PIN   (1<<5)

task_t task_01;
task_t task_02;
task_t task_03;
task_t task_idle;

void task_01_func(void)
{		
	  printf("task_01\r\n");
	
	  BOS_WaitEvent(&task_01, EVT_MASK_01);
	  BOS_ClearEvent(EVT_MASK_01);	
    
	  printf("task_01 wake up\r\n"); 	
	
    while (1)
    {
			 //printf("task_01\r\n");
       FPTE->PSOR |= RED_LED_PIN;
			 FPTD->PCOR |= GREEN_LED_PIN;
			 break; 
    }
}

void task_02_func(void)
{
	  printf("task_02\r\n"); 
	
	  BOS_WaitEvent(&task_02, EVT_MASK_02);
	  BOS_ClearEvent(EVT_MASK_02);
	
    printf("task_02 wake up\r\n"); 		
	  	
    while (1)
    {
			 FPTD->PSOR |= GREEN_LED_PIN;
       FPTE->PCOR |= RED_LED_PIN;
			 break;
    }
}

void task_03_func(void)
{	
	while(1)
	{
		//printf("task_03\r\n");
		//BOS_SetEvent(EVT_MASK_01 | EVT_MASK_02);	
		//break;
		BOS_Delay(&task_03, 500);
		FPTD->PTOR |= GREEN_LED_PIN;
		
	}
}

void task_idle_func(void)
{
	printf("task_idle_func\r\n");
	while(1)
	{
	}
}

void init_led(void)
{
    /* Enable clock for PORTE & PORTD*/
    SIM->SCGC5 |= ( SIM_SCGC5_PORTD_MASK
                    | SIM_SCGC5_PORTE_MASK );
    /* 
    * Initialize the RED LED (PTE5)
    */
    PORTE->PCR[29] = PORT_PCR_MUX(1);

    /* Set the pins direction to output */
    FPTE->PDDR |= RED_LED_PIN;

    /* Set the initial output state to high */
    FPTE->PSOR |= RED_LED_PIN;

    /* 
    * Initialize the Green LED (PTE5)
    */

    /* Set the PTE29 pin multiplexer to GPIO mode */
    PORTD->PCR[5]= PORT_PCR_MUX(1);

    /* Set the pins direction to output */
    FPTD->PDDR |= GREEN_LED_PIN;

    /* Set the initial output state to high */
    FPTD->PSOR |= GREEN_LED_PIN;
}

int main (void)
{
  SystemCoreClockUpdate();
	
	UART0_Init();
	
	init_led();
	
	printf("\r\nARM CM0+ BOS DEMO\r\n\r\n");
	
  BOS_TaskInit(&task_01, task_01_func, 1);
  BOS_TaskInit(&task_02, task_02_func, 0);	
  BOS_TaskInit(&task_03, task_03_func, 2);	
  BOS_TaskInit(&task_idle, task_idle_func, 6);
	BOS_Start();
	
	
	printf("CMXOS Terminated\r\n");
	
	while(1)
	{
	}
}

